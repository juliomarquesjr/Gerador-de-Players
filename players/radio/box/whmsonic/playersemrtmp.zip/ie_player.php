<script type=text/javascript src=player.js></script>
<script type=text/javascript>swfobject.registerObject(myId, 9.0.0);</script>
<div>
<object id=myId classid=clsid:D27CDB6E-AE6D-11cf-96B8-444553540000 width=372 height=60>
<param name=movie value=WHMSonic.swf />
<param name='flashvars' value='source=<? echo $_GET['radio']; ?>&twitter=https://twitter.com/<? echo $_GET['twitter']; ?>&facebook=http://www.facebook.com/<? echo $_GET['facebook']; ?>&volume=90&autoplay=true'>
<!--[if !IE]>-->
<object type=application/x-shockwave-flash data=WHMSonic.swf width=372 height=60>
<param name='flashvars' value='source=<? echo $_GET['radio']; ?>&twitter=https://twitter.com/<? echo $_GET['twitter']; ?>&facebook=http://www.facebook.com/<? echo $_GET['facebook']; ?>&volume=90&autoplay=true'>
<!--<![endif]-->
<!--[if !IE]>-->
</object>
<!--<![endif]-->
</object>
</div>